import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;

/**
 * Write a description of class ScrollingWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ScrollingWorld extends World
{
    int moverX = 0;
    int moverY = 0;
    /**
     * Constructor for objects of class ScrollingWorld.
     * 
     */
    public ScrollingWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1, false); 
        Lobster lobster = new Lobster();
        addObject(lobster, getWidth()/2, getHeight()/2);

        prepare();
    }

    public void moveWorld(Actor mover, int deltaX, int deltaY)
    {

        List<Actor> allActors = getObjects(Actor.class);
        for(Actor a : allActors)
        {
            if(!a.equals(mover))
            {
                    a.setLocation(a.getX()+deltaX, a.getY()+deltaY);
            }
        }
    }

    public void scrollAround(Actor mover)
    {
        if(moverX == 0)
        {
            moverX = mover.getX();
            moverY = mover.getY();
        } else if (mover.getX()!=moverX || mover.getY()!=moverY)
        {
            int dX = moverX - mover.getX() ;
            int dY =  moverY - mover.getY();
            moveWorld(mover, dX, dY);
            mover.setLocation(moverX, moverY);
        }

    }

    /**
     * Prepare the world for the start of the program. That is: create the initial
     * objects and add them to the world.
     */
    private void prepare()
    {
        fish fish = new fish();
        addObject(fish, 396, 85);
        redbug redbug = new redbug();
        addObject(redbug, 82, 308);
    }
}
